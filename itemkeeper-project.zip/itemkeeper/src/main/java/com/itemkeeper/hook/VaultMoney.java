package com.itemkeeper.hook;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/** Vault ekonomi köprüsü. Sağlayıcı her çağrıda çözülür (geç kayıt olan ekonomiler için). */
public final class VaultMoney implements MoneyProvider {

    private Economy economy() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }

    @Override
    public boolean available() {
        return economy() != null;
    }

    @Override
    public double balance(Player player) {
        Economy e = economy();
        return e == null ? 0 : e.getBalance(player);
    }

    @Override
    public boolean has(Player player, double amount) {
        Economy e = economy();
        return e != null && e.has(player, amount);
    }

    @Override
    public boolean withdraw(Player player, double amount) {
        Economy e = economy();
        if (e == null) {
            return false;
        }
        EconomyResponse r = e.withdrawPlayer(player, amount);
        return r != null && r.transactionSuccess();
    }

    @Override
    public boolean deposit(Player player, double amount) {
        Economy e = economy();
        if (e == null) {
            return false;
        }
        EconomyResponse r = e.depositPlayer(player, amount);
        return r != null && r.transactionSuccess();
    }
}
