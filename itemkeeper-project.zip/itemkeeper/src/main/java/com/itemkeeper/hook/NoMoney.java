package com.itemkeeper.hook;

import org.bukkit.entity.Player;

/** Vault/ekonomi yoksa kullanılan boş sağlayıcı: hiçbir işlem yapılmaz. */
public final class NoMoney implements MoneyProvider {
    @Override
    public boolean available() {
        return false;
    }

    @Override
    public double balance(Player player) {
        return 0;
    }

    @Override
    public boolean has(Player player, double amount) {
        return false;
    }

    @Override
    public boolean withdraw(Player player, double amount) {
        return false;
    }

    @Override
    public boolean deposit(Player player, double amount) {
        return false;
    }
}
