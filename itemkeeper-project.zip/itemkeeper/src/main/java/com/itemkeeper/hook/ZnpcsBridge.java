package com.itemkeeper.hook;

import io.github.gonalez.znpcs.npc.NPC;

import java.util.ArrayList;
import java.util.List;

/**
 * ZNPCs 5.3 köprüsü (plugin adı "ServersNPC"). Doğrulanan API:
 * NPC.find(int), NPC.all(), NPC#getNpcPojo().getId().
 */
public final class ZnpcsBridge implements NpcBridge {

    @Override
    public boolean exists(int npcId) {
        return NPC.find(npcId) != null;
    }

    @Override
    public List<Integer> allIds() {
        List<Integer> ids = new ArrayList<>();
        for (NPC npc : NPC.all()) {
            if (npc != null && npc.getNpcPojo() != null) {
                ids.add(npc.getNpcPojo().getId());
            }
        }
        ids.sort(Integer::compareTo);
        return ids;
    }
}
