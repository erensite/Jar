package com.itemkeeper.hook;

import java.util.List;

/** ZNPCs soyutlaması; ZNPCs yokken sınıf yüklenmez. */
public interface NpcBridge {

    /** Verilen kimlikte NPC var mı? (ZNPCs'in kendi NPC kayıt defteri üzerinden) */
    boolean exists(int npcId);

    /** Kayıtlı tüm NPC kimlikleri. */
    List<Integer> allIds();
}
