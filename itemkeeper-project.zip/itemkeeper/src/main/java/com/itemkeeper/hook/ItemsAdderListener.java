package com.itemkeeper.hook;

import com.itemkeeper.ItemKeeperPlugin;
import dev.lone.itemsadder.api.Events.ItemsAdderLoadDataEvent;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/** ItemsAdder eşyaları (yeniden) yüklendiğinde shop eşya ID'lerini doğrular. */
public final class ItemsAdderListener implements Listener {

    private final ItemKeeperPlugin plugin;

    public ItemsAdderListener(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onLoad(ItemsAdderLoadDataEvent event) {
        Runnable task = () -> {
            plugin.resolver().resetWarnings();
            plugin.shops().validateAll();
            plugin.gui().refreshAll();
        };
        if (Bukkit.isPrimaryThread()) {
            task.run();
        } else if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }
}
