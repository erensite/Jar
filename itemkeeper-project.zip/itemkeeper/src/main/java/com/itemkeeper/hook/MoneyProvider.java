package com.itemkeeper.hook;

import org.bukkit.entity.Player;

/** Ekonomi soyutlaması. Vault yokken sınıflar yüklenmez. */
public interface MoneyProvider {

    boolean available();

    double balance(Player player);

    boolean has(Player player, double amount);

    /** @return para gerçekten çekildiyse true */
    boolean withdraw(Player player, double amount);

    /** @return para gerçekten yatırıldıysa true */
    boolean deposit(Player player, double amount);
}
