package com.itemkeeper.hook;

import org.bukkit.inventory.ItemStack;

/** Özel eşya sağlayıcı (ItemsAdder) soyutlaması; ItemsAdder yokken sınıf yüklenmez. */
public interface CustomItemProvider {

    /** Eşya kayıtları yüklendi mi? */
    boolean isLoaded();

    boolean exists(String namespacedId);

    /** @return yeni bir kopya veya bulunamazsa null */
    ItemStack create(String namespacedId);

    /** @return eşya özel eşya ise "namespace:id", değilse null */
    String idOf(ItemStack stack);
}
