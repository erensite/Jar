package com.itemkeeper.hook;

import com.itemkeeper.ItemKeeperPlugin;
import io.github.gonalez.znpcs.npc.NPC;
import io.github.gonalez.znpcs.npc.event.NPCInteractEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/** ZNPCs'in NPCInteractEvent'ini dinler; bağlı shop'u açar. */
public final class ZnpcsListener implements Listener {

    private final ItemKeeperPlugin plugin;

    public ZnpcsListener(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(NPCInteractEvent event) {
        Player player = event.getPlayer();
        NPC npc = event.getNpc();
        if (player == null || npc == null || npc.getNpcPojo() == null) {
            return;
        }
        boolean right = event.isRightClick();
        boolean left = event.isLeftClick();
        int npcId = npc.getNpcPojo().getId();
        // Hızlı eleme: bağlantısı olmayan NPC'lere dokunma
        if (plugin.bindings().get(npcId) == null) {
            return;
        }
        String type = plugin.getConfig().getString("npc.click-type", "RIGHT").toUpperCase();
        boolean accepted = switch (type) {
            case "LEFT" -> left;
            case "BOTH" -> left || right;
            default -> right;
        };
        if (!accepted) {
            return;
        }
        // ZNPCs paket thread'inden gelebilir; Bukkit envanter işlemleri ana thread'de yapılmalı.
        if (Bukkit.isPrimaryThread()) {
            plugin.gui().openForNpc(player, npcId);
        } else if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, () -> plugin.gui().openForNpc(player, npcId));
        }
    }
}
