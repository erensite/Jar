package com.itemkeeper.hook;

import dev.lone.itemsadder.api.CustomStack;
import dev.lone.itemsadder.api.ItemsAdder;
import org.bukkit.inventory.ItemStack;

/**
 * ItemsAdder 4.0.15 API köprüsü. Kullanılan metotlar jar içinden javap ile doğrulandı:
 * ItemsAdder.areItemsLoaded(), CustomStack.isInRegistry(String), CustomStack.getInstance(String),
 * CustomStack#getItemStack(), CustomStack.byItemStack(ItemStack), CustomStack#getNamespacedID().
 */
public final class ItemsAdderBridge implements CustomItemProvider {

    @Override
    public boolean isLoaded() {
        return ItemsAdder.areItemsLoaded();
    }

    @Override
    public boolean exists(String namespacedId) {
        return CustomStack.isInRegistry(namespacedId);
    }

    @Override
    public ItemStack create(String namespacedId) {
        CustomStack cs = CustomStack.getInstance(namespacedId);
        if (cs == null) {
            return null;
        }
        ItemStack st = cs.getItemStack();
        return st == null ? null : st.clone();
    }

    @Override
    public String idOf(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return null;
        }
        CustomStack cs = CustomStack.byItemStack(stack);
        return cs == null ? null : cs.getNamespacedID();
    }
}
