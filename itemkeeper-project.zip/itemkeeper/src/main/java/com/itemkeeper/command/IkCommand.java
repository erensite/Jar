package com.itemkeeper.command;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.shop.Shop;
import com.itemkeeper.shop.ShopItem;
import com.itemkeeper.shop.ShopManager;
import com.itemkeeper.util.MessageService;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** /itemkeeper ve /ik komutları. */
public final class IkCommand implements CommandExecutor, TabCompleter {

    private final ItemKeeperPlugin plugin;

    public IkCommand(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    private static boolean has(CommandSender s, String perm) {
        return s.hasPermission(perm) || s.hasPermission("itemkeeper.admin");
    }

    private boolean need(CommandSender s, String perm) {
        if (has(s, perm)) {
            return true;
        }
        plugin.messages().send(s, "general.no-permission");
        return false;
    }

    private Player playerOnly(CommandSender s) {
        if (s instanceof Player p) {
            return p;
        }
        plugin.messages().send(s, "general.player-only");
        return null;
    }

    private void usage(CommandSender s, String usage) {
        plugin.messages().send(s, "general.usage", "usage", usage);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        MessageService msg = plugin.messages();
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(msg.format("help.header"));
            for (String line : msg.formatList("help.lines")) {
                sender.sendMessage(line);
            }
            return true;
        }
        try {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "reload" -> reload(sender);
                case "shop" -> shop(sender, args);
                case "npc" -> npc(sender, args);
                case "item" -> item(sender, args);
                default -> msg.send(sender, "general.unknown-subcommand");
            }
        } catch (RuntimeException | LinkageError e) {
            plugin.getLogger().severe("Komut hatası (/ik " + String.join(" ", args) + "): " + e);
            msg.send(sender, "trade.error");
        }
        return true;
    }

    private void reload(CommandSender sender) {
        if (!need(sender, "itemkeeper.reload")) {
            return;
        }
        if (plugin.reloadAll()) {
            plugin.messages().send(sender, "general.reloaded", "shops", String.valueOf(plugin.shops().count()),
                    "bindings", String.valueOf(plugin.bindings().count()));
        } else {
            plugin.messages().send(sender, "general.reload-failed");
        }
    }

    // ---------------------------------------------------------------- shop

    private void shop(CommandSender sender, String[] args) {
        MessageService msg = plugin.messages();
        if (args.length < 2) {
            usage(sender, "/ik shop <list|create|delete|open|edit> ...");
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                if (!need(sender, "itemkeeper.shop.open")) {
                    return;
                }
                List<Shop> all = plugin.shops().all();
                if (all.isEmpty()) {
                    msg.send(sender, "shop.list-empty");
                    return;
                }
                msg.send(sender, "shop.list-header", "count", String.valueOf(all.size()));
                for (Shop s : all) {
                    sender.sendMessage(msg.format("shop.list-entry", "id", s.id(), "title", MessageService.color(s.title()),
                            "items", String.valueOf(s.items().size())));
                }
            }
            case "create" -> {
                if (!need(sender, "itemkeeper.shop.create")) {
                    return;
                }
                if (args.length < 3) {
                    usage(sender, "/ik shop create <id>");
                    return;
                }
                String id = args[2].toLowerCase(Locale.ROOT);
                if (!ShopManager.validId(id)) {
                    msg.send(sender, "shop.invalid-id");
                    return;
                }
                if (plugin.shops().get(id) != null) {
                    msg.send(sender, "shop.exists", "id", id);
                    return;
                }
                plugin.shops().create(id);
                if (!plugin.shops().save()) {
                    msg.send(sender, "shop.save-failed");
                }
                msg.send(sender, "shop.created", "id", id);
            }
            case "delete" -> {
                if (!need(sender, "itemkeeper.shop.delete")) {
                    return;
                }
                if (args.length < 3) {
                    usage(sender, "/ik shop delete <id>");
                    return;
                }
                Shop s = plugin.shops().get(args[2]);
                if (s == null) {
                    msg.send(sender, "shop.not-found", "id", args[2]);
                    return;
                }
                plugin.shops().delete(s.id());
                int unbound = plugin.bindings().unbindShop(s.id());
                boolean ok = plugin.shops().save();
                if (unbound > 0) {
                    ok &= plugin.bindings().save();
                }
                if (!ok) {
                    msg.send(sender, "shop.save-failed");
                }
                plugin.gui().refreshAll(); // açık arayüzleri kapatır
                msg.send(sender, "shop.deleted", "id", s.id(), "unbound", String.valueOf(unbound));
            }
            case "open", "edit" -> {
                boolean edit = sub.equals("edit");
                if (!need(sender, edit ? "itemkeeper.shop.edit" : "itemkeeper.shop.open")) {
                    return;
                }
                Player p = playerOnly(sender);
                if (p == null) {
                    return;
                }
                if (args.length < 3) {
                    usage(sender, "/ik shop " + sub + " <id>");
                    return;
                }
                Shop s = plugin.shops().get(args[2]);
                if (s == null) {
                    msg.send(sender, "shop.not-found", "id", args[2]);
                    return;
                }
                plugin.gui().openShop(p, s, edit);
            }
            default -> msg.send(sender, "general.unknown-subcommand");
        }
    }

    // ----------------------------------------------------------------- npc

    private Integer parseNpcId(CommandSender sender, String raw) {
        try {
            return Integer.parseInt(raw.replace("#", "").trim());
        } catch (NumberFormatException e) {
            plugin.messages().send(sender, "npc.invalid-id", "value", raw);
            return null;
        }
    }

    private void npc(CommandSender sender, String[] args) {
        MessageService msg = plugin.messages();
        if (!need(sender, "itemkeeper.npc.bind")) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/ik npc <bind|unbind|info|list> ...");
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "bind" -> {
                if (args.length < 4) {
                    usage(sender, "/ik npc bind <npc-id> <shop-id>");
                    return;
                }
                if (plugin.npcs() == null) {
                    msg.send(sender, "npc.znpcs-missing");
                    return;
                }
                Integer npcId = parseNpcId(sender, args[2]);
                if (npcId == null) {
                    return;
                }
                if (!plugin.npcs().exists(npcId)) {
                    msg.send(sender, "npc.not-found", "npc", String.valueOf(npcId));
                    return;
                }
                Shop s = plugin.shops().get(args[3]);
                if (s == null) {
                    msg.send(sender, "shop.not-found", "id", args[3]);
                    return;
                }
                String old = plugin.bindings().bind(npcId, s.id());
                if (!plugin.bindings().save()) {
                    msg.send(sender, "shop.save-failed");
                }
                plugin.gui().resetWarnings();
                if (old == null) {
                    msg.send(sender, "npc.bound", "npc", String.valueOf(npcId), "shop", s.id());
                } else {
                    msg.send(sender, "npc.rebound", "npc", String.valueOf(npcId), "old", old, "shop", s.id());
                }
            }
            case "unbind" -> {
                if (args.length < 3) {
                    usage(sender, "/ik npc unbind <npc-id>");
                    return;
                }
                Integer npcId = parseNpcId(sender, args[2]);
                if (npcId == null) {
                    return;
                }
                if (!plugin.bindings().unbind(npcId)) {
                    msg.send(sender, "npc.not-bound", "npc", String.valueOf(npcId));
                    return;
                }
                if (!plugin.bindings().save()) {
                    msg.send(sender, "shop.save-failed");
                }
                msg.send(sender, "npc.unbound", "npc", String.valueOf(npcId));
            }
            case "info" -> {
                if (args.length < 3) {
                    usage(sender, "/ik npc info <npc-id>");
                    return;
                }
                Integer npcId = parseNpcId(sender, args[2]);
                if (npcId == null) {
                    return;
                }
                String shopId = plugin.bindings().get(npcId);
                if (shopId == null) {
                    msg.send(sender, "npc.not-bound", "npc", String.valueOf(npcId));
                    return;
                }
                String shopState = plugin.shops().get(shopId) != null ? msg.format("npc.state-ok") : msg.format("npc.state-missing");
                String npcState = plugin.npcs() == null ? msg.format("npc.state-unknown")
                        : (plugin.npcs().exists(npcId) ? msg.format("npc.state-ok") : msg.format("npc.state-missing"));
                msg.send(sender, "npc.info", "npc", String.valueOf(npcId), "shop", shopId, "shopstate", shopState, "npcstate", npcState);
            }
            case "list" -> {
                Map<Integer, String> all = plugin.bindings().all();
                if (all.isEmpty()) {
                    msg.send(sender, "npc.list-empty");
                    return;
                }
                msg.send(sender, "npc.list-header", "count", String.valueOf(all.size()));
                for (Map.Entry<Integer, String> e : all.entrySet()) {
                    sender.sendMessage(msg.format("npc.list-entry", "npc", String.valueOf(e.getKey()), "shop", e.getValue()));
                }
            }
            default -> msg.send(sender, "general.unknown-subcommand");
        }
    }

    // ---------------------------------------------------------------- item

    /** @return null: geçersiz; -1: kapalı ("-" veya 0); aksi halde fiyat */
    private Double parsePrice(CommandSender sender, String raw) {
        if (raw.equals("-")) {
            return 0d;
        }
        double v;
        try {
            v = Double.parseDouble(raw.replace(',', '.'));
        } catch (NumberFormatException e) {
            plugin.messages().send(sender, "item.bad-price", "value", raw);
            return null;
        }
        double max = plugin.getConfig().getDouble("trade.max-price", 1_000_000_000d);
        if (Double.isNaN(v) || Double.isInfinite(v) || v < 0 || v > max) {
            plugin.messages().send(sender, "item.bad-price", "value", raw);
            return null;
        }
        return v;
    }

    private void item(CommandSender sender, String[] args) {
        MessageService msg = plugin.messages();
        if (!need(sender, "itemkeeper.item.manage")) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/ik item <info|add|remove> ...");
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "info" -> {
                Player p = playerOnly(sender);
                if (p == null) {
                    return;
                }
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand == null || hand.getType().isAir()) {
                    msg.send(sender, "item.hand-empty");
                    return;
                }
                String ia = plugin.resolver().customIdOf(hand);
                sender.sendMessage(msg.format("item.info-material", "material", hand.getType().name()));
                sender.sendMessage(msg.format("item.info-ia", "ia", ia == null ? msg.format("item.info-none") : ia));
                sender.sendMessage(msg.format("item.info-key", "key", plugin.resolver().keyOf(hand)));
            }
            case "add" -> {
                Player p = playerOnly(sender);
                if (p == null) {
                    return;
                }
                if (args.length < 5) {
                    usage(sender, "/ik item add <shop-id> <alış-fiyatı> <satış-fiyatı> [adet]");
                    return;
                }
                Shop s = plugin.shops().get(args[2]);
                if (s == null) {
                    msg.send(sender, "shop.not-found", "id", args[2]);
                    return;
                }
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand == null || hand.getType().isAir()) {
                    msg.send(sender, "item.hand-empty");
                    return;
                }
                Double buy = parsePrice(sender, args[3]);
                Double sell = parsePrice(sender, args[4]);
                if (buy == null || sell == null) {
                    return;
                }
                if (buy <= 0 && sell <= 0) {
                    msg.send(sender, "item.both-disabled");
                    return;
                }
                int amount = 1;
                if (args.length >= 6) {
                    try {
                        amount = Integer.parseInt(args[5]);
                    } catch (NumberFormatException e) {
                        msg.send(sender, "general.invalid-number", "value", args[5]);
                        return;
                    }
                    if (amount < 1 || amount > 64) {
                        msg.send(sender, "item.bad-amount");
                        return;
                    }
                }
                String key = plugin.resolver().keyOf(hand);
                if (plugin.customItems() == null) {
                    msg.send(sender, "item.ia-hook-missing");
                }
                ShopItem it = new ShopItem(key, amount, buy, sell);
                s.items().add(it);
                if (!plugin.shops().save()) {
                    msg.send(sender, "shop.save-failed");
                }
                plugin.gui().refreshAll();
                msg.send(sender, "item.added", "item", key, "amount", String.valueOf(amount),
                        "buy", it.canBuy() ? plugin.fmt(it.buyPrice()) : "-",
                        "sell", it.canSell() ? plugin.fmt(it.sellPrice()) : "-",
                        "slot", String.valueOf(s.items().size()));
            }
            case "remove" -> {
                if (args.length < 4) {
                    usage(sender, "/ik item remove <shop-id> <sıra>");
                    return;
                }
                Shop s = plugin.shops().get(args[2]);
                if (s == null) {
                    msg.send(sender, "shop.not-found", "id", args[2]);
                    return;
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    msg.send(sender, "general.invalid-number", "value", args[3]);
                    return;
                }
                if (slot < 1 || slot > s.items().size()) {
                    msg.send(sender, "item.bad-slot", "max", String.valueOf(s.items().size()));
                    return;
                }
                ShopItem removed = s.items().remove(slot - 1);
                if (!plugin.shops().save()) {
                    msg.send(sender, "shop.save-failed");
                }
                plugin.gui().refreshAll();
                msg.send(sender, "item.removed", "item", removed.itemId(), "slot", String.valueOf(slot));
            }
            default -> msg.send(sender, "general.unknown-subcommand");
        }
    }

    // ------------------------------------------------------- tab completion

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
            }
        }
        return out;
    }

    private List<String> shopIds() {
        List<String> ids = new ArrayList<>();
        for (Shop s : plugin.shops().all()) {
            ids.add(s.id());
        }
        return ids;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> none = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("help"));
            if (has(sender, "itemkeeper.reload")) {
                subs.add("reload");
            }
            if (has(sender, "itemkeeper.shop.open") || has(sender, "itemkeeper.shop.create")
                    || has(sender, "itemkeeper.shop.edit") || has(sender, "itemkeeper.shop.delete")) {
                subs.add("shop");
            }
            if (has(sender, "itemkeeper.npc.bind")) {
                subs.add("npc");
            }
            if (has(sender, "itemkeeper.item.manage")) {
                subs.add("item");
            }
            return filter(subs, args[0]);
        }
        String a0 = args[0].toLowerCase(Locale.ROOT);
        if (a0.equals("shop")) {
            if (args.length == 2) {
                List<String> subs = new ArrayList<>();
                if (has(sender, "itemkeeper.shop.open")) {
                    subs.addAll(Arrays.asList("list", "open"));
                }
                if (has(sender, "itemkeeper.shop.create")) {
                    subs.add("create");
                }
                if (has(sender, "itemkeeper.shop.delete")) {
                    subs.add("delete");
                }
                if (has(sender, "itemkeeper.shop.edit")) {
                    subs.add("edit");
                }
                return filter(subs, args[1]);
            }
            String a1 = args[1].toLowerCase(Locale.ROOT);
            if (args.length == 3 && (a1.equals("open") || a1.equals("edit") || a1.equals("delete"))) {
                return filter(shopIds(), args[2]);
            }
            return none;
        }
        if (a0.equals("npc") && has(sender, "itemkeeper.npc.bind")) {
            if (args.length == 2) {
                return filter(List.of("bind", "unbind", "info", "list"), args[1]);
            }
            String a1 = args[1].toLowerCase(Locale.ROOT);
            if (args.length == 3 && (a1.equals("bind") || a1.equals("unbind") || a1.equals("info"))) {
                List<String> ids = new ArrayList<>();
                if (a1.equals("bind") && plugin.npcs() != null) {
                    try {
                        for (Integer id : plugin.npcs().allIds()) {
                            ids.add(String.valueOf(id));
                        }
                    } catch (RuntimeException | LinkageError ignored) {
                        // ZNPCs hazır değil; öneri verme
                    }
                } else {
                    for (Integer id : plugin.bindings().all().keySet()) {
                        ids.add(String.valueOf(id));
                    }
                }
                return filter(ids, args[2]);
            }
            if (args.length == 4 && a1.equals("bind")) {
                return filter(shopIds(), args[3]);
            }
            return none;
        }
        if (a0.equals("item") && has(sender, "itemkeeper.item.manage")) {
            if (args.length == 2) {
                return filter(List.of("info", "add", "remove"), args[1]);
            }
            String a1 = args[1].toLowerCase(Locale.ROOT);
            if (args.length == 3 && (a1.equals("add") || a1.equals("remove"))) {
                return filter(shopIds(), args[2]);
            }
            if (a1.equals("add") && (args.length == 4 || args.length == 5)) {
                return filter(List.of("-"), args[args.length - 1]);
            }
            return none;
        }
        return none;
    }
}
