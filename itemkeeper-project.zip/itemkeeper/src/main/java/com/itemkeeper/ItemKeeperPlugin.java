package com.itemkeeper;

import com.itemkeeper.command.IkCommand;
import com.itemkeeper.gui.GuiManager;
import com.itemkeeper.hook.CustomItemProvider;
import com.itemkeeper.hook.ItemsAdderBridge;
import com.itemkeeper.hook.ItemsAdderListener;
import com.itemkeeper.hook.MoneyProvider;
import com.itemkeeper.hook.NoMoney;
import com.itemkeeper.hook.NpcBridge;
import com.itemkeeper.hook.VaultMoney;
import com.itemkeeper.hook.ZnpcsBridge;
import com.itemkeeper.hook.ZnpcsListener;
import com.itemkeeper.shop.BindingManager;
import com.itemkeeper.shop.ItemResolver;
import com.itemkeeper.shop.ShopManager;
import com.itemkeeper.shop.TradeService;
import com.itemkeeper.util.MessageService;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Locale;
import java.util.Map;

public final class ItemKeeperPlugin extends JavaPlugin {

    private MessageService messages;
    private ItemResolver resolver;
    private ShopManager shops;
    private BindingManager bindings;
    private TradeService trade;
    private GuiManager gui;
    private MoneyProvider money = new NoMoney();
    private CustomItemProvider customItems; // null = ItemsAdder yok
    private NpcBridge npcs;                 // null = ZNPCs yok

    @Override
    public void onEnable() {
        saveDefaultIfMissing("config.yml");
        saveDefaultIfMissing("shops.yml");
        saveDefaultIfMissing("npc-bindings.yml");
        saveDefaultIfMissing("messages.yml");
        reloadConfig();

        messages = new MessageService(this);
        messages.load();
        resolver = new ItemResolver(this);
        shops = new ShopManager(this);
        bindings = new BindingManager(this);
        trade = new TradeService(this);
        gui = new GuiManager(this);

        setupHooks();

        if (!shops.load()) {
            getLogger().severe("shops.yml yüklenemedi; shop listesi boş başlatıldı. Dosyayı düzeltip /ik reload yazın.");
        }
        if (!bindings.load()) {
            getLogger().severe("npc-bindings.yml yüklenemedi; NPC bağlantıları boş başlatıldı. Dosyayı düzeltip /ik reload yazın.");
        }

        Bukkit.getPluginManager().registerEvents(gui, this);

        PluginCommand command = getCommand("itemkeeper");
        if (command != null) {
            IkCommand ik = new IkCommand(this);
            command.setExecutor(ik);
            command.setTabCompleter(ik);
        } else {
            getLogger().severe("'itemkeeper' komutu plugin.yml'de bulunamadı!");
        }

        long delay = Math.max(20L, getConfig().getLong("npc.validate-delay-ticks", 600L));
        Bukkit.getScheduler().runTaskLater(this, this::validateBindings, delay);
        getLogger().info("ItemKeeper etkin: " + shops.count() + " shop, " + bindings.count() + " NPC bağlantısı.");
    }

    /** Opsiyonel eklentilere bağlanır; her biri başarısız olursa ilgili özellik devre dışı kalır. */
    private void setupHooks() {
        // Vault
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            try {
                VaultMoney vm = new VaultMoney();
                money = vm;
                if (!vm.available()) {
                    getLogger().warning("Vault bulundu ama kayıtlı bir ekonomi sağlayıcısı yok; alış/satış çalışmayacak.");
                }
            } catch (LinkageError | RuntimeException e) {
                getLogger().warning("Vault bağlantısı kurulamadı: " + e);
                money = new NoMoney();
            }
        } else {
            getLogger().warning("Vault bulunamadı: alış/satış devre dışı (shop'lar sadece görüntülenebilir).");
        }
        // ItemsAdder
        if (Bukkit.getPluginManager().getPlugin("ItemsAdder") != null) {
            try {
                customItems = new ItemsAdderBridge();
                Bukkit.getPluginManager().registerEvents(new ItemsAdderListener(this), this);
                getLogger().info("ItemsAdder bağlantısı kuruldu.");
            } catch (LinkageError | RuntimeException e) {
                customItems = null;
                getLogger().warning("ItemsAdder API'si kullanılamadı; ItemsAdder eşyaları devre dışı: " + e);
            }
        } else {
            getLogger().warning("ItemsAdder bulunamadı: ItemsAdder eşyaları kullanılamaz, vanilla eşyalar çalışır.");
        }
        // ZNPCs (plugin adı: ServersNPC)
        if (Bukkit.getPluginManager().getPlugin("ServersNPC") != null) {
            try {
                npcs = new ZnpcsBridge();
                Bukkit.getPluginManager().registerEvents(new ZnpcsListener(this), this);
                getLogger().info("ZNPCs bağlantısı kuruldu.");
            } catch (LinkageError | RuntimeException e) {
                npcs = null;
                getLogger().warning("ZNPCs API'si kullanılamadı; NPC özellikleri devre dışı: " + e);
            }
        } else {
            getLogger().warning("ZNPCs (ServersNPC) bulunamadı: NPC bağlantıları devre dışı.");
        }
    }

    private void saveDefaultIfMissing(String name) {
        if (!new File(getDataFolder(), name).exists()) {
            saveResource(name, false);
        }
    }

    /** Başlangıçtan sonra, var olmayan NPC'lere bağlı kayıtları konsola yazar. */
    private void validateBindings() {
        for (Map.Entry<Integer, String> e : bindings.all().entrySet()) {
            if (shops.get(e.getValue()) == null) {
                getLogger().warning("NPC #" + e.getKey() + " mevcut olmayan shop'a bağlı: '" + e.getValue() + "'.");
            }
            if (npcs != null) {
                try {
                    if (!npcs.exists(e.getKey())) {
                        getLogger().warning("Bağlantıdaki NPC #" + e.getKey() + " ZNPCs'te bulunamadı (silinmiş olabilir). "
                                + "Kaldırmak için: /ik npc unbind " + e.getKey());
                    }
                } catch (RuntimeException | LinkageError ex) {
                    getLogger().warning("NPC doğrulaması yapılamadı: " + ex);
                    return;
                }
            }
        }
    }

    /** @return hepsi sorunsuz yüklendiyse true. Hatalı dosyada eski veri korunur. */
    public boolean reloadAll() {
        boolean ok = true;
        try {
            reloadConfig();
            ok &= messages.load();
            ok &= shops.load();
            ok &= bindings.load();
            gui.resetWarnings();
            gui.refreshAll();
        } catch (RuntimeException e) {
            getLogger().severe("Yeniden yükleme hatası: " + e);
            return false;
        }
        return ok;
    }

    @Override
    public void onDisable() {
        if (gui != null) {
            gui.closeAll();
        }
        if (trade != null) {
            trade.clear();
        }
        Bukkit.getScheduler().cancelTasks(this);
        HandlerList.unregisterAll(this);
    }

    /** Para biçimi: config'teki economy.format içindeki {amount} yerine 2 ondalıklı tutar. */
    public String fmt(double amount) {
        String fmt = getConfig().getString("economy.format", "{amount} TL");
        return fmt.replace("{amount}", String.format(Locale.US, "%.2f", amount));
    }

    public MessageService messages() {
        return messages;
    }

    public ItemResolver resolver() {
        return resolver;
    }

    public ShopManager shops() {
        return shops;
    }

    public BindingManager bindings() {
        return bindings;
    }

    public TradeService trade() {
        return trade;
    }

    public GuiManager gui() {
        return gui;
    }

    public MoneyProvider money() {
        return money;
    }

    public CustomItemProvider customItems() {
        return customItems;
    }

    public NpcBridge npcs() {
        return npcs;
    }
}
