package com.itemkeeper.gui;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.shop.Category;
import com.itemkeeper.shop.Shop;
import com.itemkeeper.shop.ShopItem;
import com.itemkeeper.shop.TradeService;
import com.itemkeeper.util.MessageService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Tek bir oyuncuya açılmış shop (veya düzenleme) arayüzü. */
public final class ShopGui implements InventoryHolder {

    static final int ITEM_SLOTS = 45;
    static final int SLOT_PREV = 45;
    static final int SLOT_CATEGORY = 46;
    static final int SLOT_MULT = 47;
    static final int SLOT_INFO = 49;
    static final int SLOT_NEXT = 53;

    private final ItemKeeperPlugin plugin;
    private final UUID viewer;
    private final String shopId;
    private final boolean edit;
    private final Inventory inventory;
    private final List<ShopItem> visible = new ArrayList<>();
    private final List<Integer> multipliers;
    private int page = 0;
    private int categoryIndex = -1; // -1 = tümü
    private int multIndex = 0;

    public ShopGui(ItemKeeperPlugin plugin, Player viewer, Shop shop, boolean edit) {
        this.plugin = plugin;
        this.viewer = viewer.getUniqueId();
        this.shopId = shop.id();
        this.edit = edit;
        this.multipliers = readMultipliers(plugin);
        String title = MessageService.color(shop.title());
        if (edit) {
            title += plugin.messages().format("gui.edit-title-suffix");
        }
        if (title.length() > 32) {
            title = title.substring(0, 32);
        }
        this.inventory = Bukkit.createInventory(this, 54, title);
    }

    private static List<Integer> readMultipliers(ItemKeeperPlugin plugin) {
        List<Integer> out = new ArrayList<>();
        for (Integer i : plugin.getConfig().getIntegerList("trade.multipliers")) {
            if (i != null && i >= 1 && i <= 64 && !out.contains(i)) {
                out.add(i);
            }
        }
        if (out.isEmpty()) {
            out.add(1);
        }
        return out;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public UUID viewer() {
        return viewer;
    }

    public String shopId() {
        return shopId;
    }

    private int multiplier() {
        return multipliers.get(multIndex % multipliers.size());
    }

    /** Arayüzü mevcut shop verisinden yeniden çizer. @return shop yoksa false */
    public boolean render() {
        Shop shop = plugin.shops().get(shopId);
        if (shop == null) {
            return false;
        }
        MessageService msg = plugin.messages();
        List<Category> cats = new ArrayList<>(shop.categories().values());
        if (categoryIndex >= cats.size()) {
            categoryIndex = -1;
        }
        visible.clear();
        for (ShopItem it : shop.items()) {
            if (categoryIndex < 0 || (it.category() != null && it.category().equals(cats.get(categoryIndex).id()))) {
                visible.add(it);
            }
        }
        int pages = Math.max(1, (visible.size() + ITEM_SLOTS - 1) / ITEM_SLOTS);
        if (page >= pages) {
            page = pages - 1;
        }
        inventory.clear();
        ItemStack filler = simple(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int s = ITEM_SLOTS; s < 54; s++) {
            inventory.setItem(s, filler);
        }
        for (int s = 0; s < ITEM_SLOTS; s++) {
            int idx = page * ITEM_SLOTS + s;
            if (idx >= visible.size()) {
                break;
            }
            inventory.setItem(s, icon(shop, visible.get(idx)));
        }
        if (visible.isEmpty()) {
            inventory.setItem(22, simple(Material.BARRIER, msg.format("gui.empty")));
        }
        if (page > 0) {
            inventory.setItem(SLOT_PREV, simple(Material.ARROW, msg.format("gui.prev")));
        }
        if (page < pages - 1) {
            inventory.setItem(SLOT_NEXT, simple(Material.ARROW, msg.format("gui.next")));
        }
        inventory.setItem(48, simple(Material.PAPER, msg.format("gui.page", "page", String.valueOf(page + 1), "pages", String.valueOf(pages))));
        if (!cats.isEmpty()) {
            String name;
            Material mat = Material.BOOKSHELF;
            if (categoryIndex < 0) {
                name = msg.format("gui.category-all");
            } else {
                Category c = cats.get(categoryIndex);
                name = MessageService.color(c.name());
                if (c.icon() != null) {
                    ItemStack ic = plugin.resolver().create(c.icon());
                    if (ic != null) {
                        mat = ic.getType();
                    }
                }
            }
            inventory.setItem(SLOT_CATEGORY, simple(mat, msg.format("gui.category-title", "name", name), msg.format("gui.category-hint")));
        }
        if (edit) {
            inventory.setItem(SLOT_MULT, simple(Material.REDSTONE_TORCH, msg.format("gui.edit-mode")));
        } else {
            inventory.setItem(SLOT_MULT, simple(Material.HOPPER, msg.format("gui.multiplier-title", "mult", String.valueOf(multiplier())), msg.format("gui.multiplier-hint")));
            renderBalance();
        }
        return true;
    }

    /** Sadece bakiye göstergesini yeniler. */
    public void renderBalance() {
        if (edit) {
            return;
        }
        Player p = Bukkit.getPlayer(viewer);
        MessageService msg = plugin.messages();
        String text = (p != null && plugin.money().available())
                ? msg.format("gui.balance", "balance", plugin.fmt(plugin.money().balance(p)))
                : msg.format("gui.balance-unknown");
        inventory.setItem(SLOT_INFO, simple(Material.GOLD_INGOT, text));
    }

    private static ItemStack simple(Material m, String name, String... lore) {
        ItemStack st = new ItemStack(m);
        ItemMeta meta = st.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) {
                List<String> l = new ArrayList<>();
                for (String s : lore) {
                    l.add(s);
                }
                meta.setLore(l);
            }
            st.setItemMeta(meta);
        }
        return st;
    }

    private ItemStack icon(Shop shop, ShopItem it) {
        MessageService msg = plugin.messages();
        ItemStack base = it.icon() != null ? plugin.resolver().create(it.icon()) : null;
        if (base == null) {
            base = plugin.resolver().create(it.itemId());
        }
        boolean missing = base == null;
        ItemStack st = missing ? new ItemStack(Material.BARRIER) : base.clone();
        if (!missing) {
            st.setAmount(Math.max(1, Math.min(it.amount(), st.getMaxStackSize())));
        }
        ItemMeta meta = st.getItemMeta();
        if (meta == null) {
            return st;
        }
        List<String> lore = new ArrayList<>();
        if (missing) {
            meta.setDisplayName(msg.format("gui.missing-item-name"));
            lore.add(msg.format("gui.missing-item-lore", "id", it.itemId()));
        } else {
            if (it.name() != null) {
                meta.setDisplayName(MessageService.color(it.name()));
            }
            if (meta.hasLore() && meta.getLore() != null) {
                lore.addAll(meta.getLore());
            }
        }
        for (String l : it.lore()) {
            lore.add(MessageService.color(l));
        }
        String disabled = msg.format("gui.lore.disabled");
        lore.add(msg.format("gui.lore.amount", "amount", String.valueOf(it.amount())));
        if (edit) {
            lore.add(msg.format("gui.lore.edit-buy", "price", it.canBuy() ? plugin.fmt(it.buyPrice()) : disabled));
            lore.add(msg.format("gui.lore.edit-sell", "price", it.canSell() ? plugin.fmt(it.sellPrice()) : disabled));
            lore.add(msg.format("gui.lore.edit-remove"));
        } else {
            int m = multiplier();
            if (it.canBuy()) {
                lore.add(msg.format("gui.lore.buy", "price", plugin.fmt(it.buyPrice() * m)));
            }
            if (it.canSell()) {
                lore.add(msg.format("gui.lore.sell", "price", plugin.fmt(it.sellPrice() * m)));
            }
        }
        meta.setLore(lore);
        st.setItemMeta(meta);
        return st;
    }

    /** İtem etiketi: özel ad varsa o, yoksa eşya kimliği. */
    public static String label(ShopItem it) {
        if (it.name() != null) {
            return ChatColor.stripColor(MessageService.color(it.name()));
        }
        return it.itemId();
    }

    /** Üst envanterdeki bir slota tıklama. */
    public void handleClick(Player p, int rawSlot, ClickType click) {
        if (!p.getUniqueId().equals(viewer)) {
            return;
        }
        Shop shop = plugin.shops().get(shopId);
        if (shop == null) {
            p.closeInventory();
            plugin.messages().send(p, "shop.removed-while-open");
            return;
        }
        if (rawSlot < 0 || rawSlot >= 54) {
            return;
        }
        if (rawSlot < ITEM_SLOTS) {
            int idx = page * ITEM_SLOTS + rawSlot;
            if (idx >= visible.size()) {
                return;
            }
            ShopItem item = visible.get(idx);
            if (!shop.containsItem(item)) { // shop yeniden yüklendi/değişti
                render();
                return;
            }
            if (edit) {
                handleEdit(p, shop, item, click);
            } else {
                handleTrade(p, shop, item, click);
            }
            return;
        }
        switch (rawSlot) {
            case SLOT_PREV -> {
                if (page > 0) {
                    page--;
                    render();
                }
            }
            case SLOT_NEXT -> {
                page++;
                render();
            }
            case SLOT_CATEGORY -> {
                if (!shop.categories().isEmpty()) {
                    categoryIndex++;
                    if (categoryIndex >= shop.categories().size()) {
                        categoryIndex = -1;
                    }
                    page = 0;
                    render();
                }
            }
            case SLOT_MULT -> {
                if (!edit) {
                    multIndex = (multIndex + 1) % multipliers.size();
                    render();
                }
            }
            default -> {
            }
        }
    }

    private void handleTrade(Player p, Shop shop, ShopItem item, ClickType click) {
        MessageService msg = plugin.messages();
        if (shop.permission() != null && !p.hasPermission(shop.permission()) && !p.hasPermission("itemkeeper.admin")) {
            msg.send(p, "shop.no-permission-shop");
            return;
        }
        boolean buy = click == ClickType.LEFT || click == ClickType.SHIFT_LEFT;
        boolean sell = click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT;
        if (!buy && !sell) {
            return;
        }
        int mult = multiplier();
        TradeService.Outcome o = buy ? plugin.trade().buy(p, shop, item, mult) : plugin.trade().sell(p, shop, item, mult);
        String items = String.valueOf(o.items());
        switch (o.result()) {
            case SUCCESS -> {
                msg.send(p, buy ? "trade.bought" : "trade.sold", "amount", items, "item", label(item), "price", plugin.fmt(o.money()));
                if (o.partial()) {
                    msg.send(p, "trade.refunded-partial");
                }
            }
            case NO_ECONOMY -> msg.send(p, "trade.no-economy");
            case DISABLED -> msg.send(p, buy ? "trade.buy-disabled" : "trade.sell-disabled");
            case NOT_ENOUGH_MONEY -> msg.send(p, "trade.not-enough-money", "price", plugin.fmt(o.money()));
            case INVENTORY_FULL -> msg.send(p, "trade.inventory-full");
            case NOT_ENOUGH_ITEMS -> msg.send(p, "trade.not-enough-items", "amount", items, "item", label(item));
            case ITEM_MISSING -> msg.send(p, "trade.item-missing");
            case BUSY -> msg.send(p, "trade.busy");
            default -> msg.send(p, "trade.error");
        }
        renderBalance();
    }

    private void handleEdit(Player p, Shop shop, ShopItem item, ClickType click) {
        MessageService msg = plugin.messages();
        if (!p.hasPermission("itemkeeper.shop.edit") && !p.hasPermission("itemkeeper.admin")) {
            msg.send(p, "general.no-permission");
            p.closeInventory();
            return;
        }
        double step = Math.max(0.01, plugin.getConfig().getDouble("editor.price-step", 1.0));
        double max = plugin.getConfig().getDouble("trade.max-price", 1_000_000_000d);
        boolean changed = true;
        switch (click) {
            case LEFT -> item.setBuyPrice(Math.min(max, item.buyPrice() + step));
            case RIGHT -> item.setBuyPrice(item.buyPrice() - step);
            case SHIFT_LEFT -> item.setSellPrice(Math.min(max, item.sellPrice() + step));
            case SHIFT_RIGHT -> item.setSellPrice(item.sellPrice() - step);
            case DROP, CONTROL_DROP -> shop.items().remove(item);
            default -> changed = false;
        }
        if (!changed) {
            return;
        }
        if (!plugin.shops().save()) {
            msg.send(p, "shop.save-failed");
        }
        render();
    }
}
