package com.itemkeeper.gui;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.shop.Shop;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Açık shop arayüzlerini izler ve envanter olaylarını yönetir.
 * Üst envanter bizimse tüm tıklama/sürüklemeler iptal edilir (eşya alma/koyma/sahte eşya engeli).
 */
public final class GuiManager implements Listener {

    private final ItemKeeperPlugin plugin;
    private final Map<UUID, ShopGui> open = new HashMap<>();
    private final Map<UUID, Long> npcCooldown = new HashMap<>();
    private final Set<Integer> warnedNpc = new HashSet<>();

    public GuiManager(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean openShop(Player player, Shop shop, boolean edit) {
        ShopGui gui = new ShopGui(plugin, player, shop, edit);
        if (!gui.render()) {
            return false;
        }
        player.openInventory(gui.getInventory());
        open.put(player.getUniqueId(), gui);
        return true;
    }

    /** ZNPCs tıklaması: NPC'ye bağlı shop'u açar; eksik shop/NPC durumunda güvenle davranır. */
    public void openForNpc(Player player, int npcId) {
        String shopId = plugin.bindings().get(npcId);
        if (shopId == null) {
            return;
        }
        long now = System.currentTimeMillis();
        long cd = Math.max(0, plugin.getConfig().getLong("npc.open-cooldown-ms", 500));
        Long prev = npcCooldown.get(player.getUniqueId());
        if (prev != null && now - prev < cd) {
            return;
        }
        npcCooldown.put(player.getUniqueId(), now);
        Shop shop = plugin.shops().get(shopId);
        if (shop == null) {
            if (warnedNpc.add(npcId)) {
                plugin.getLogger().warning("NPC #" + npcId + " silinmiş/bulunamayan shop'a bağlı: '" + shopId
                        + "'. /ik npc bind veya /ik npc unbind ile düzeltin.");
            }
            plugin.messages().send(player, "npc.click-no-shop");
            return;
        }
        if (shop.permission() != null && !player.hasPermission(shop.permission()) && !player.hasPermission("itemkeeper.admin")) {
            plugin.messages().send(player, "shop.no-permission-shop");
            return;
        }
        openShop(player, shop, false);
    }

    public void resetWarnings() {
        warnedNpc.clear();
    }

    /** Açık arayüzleri kapatır (reload/disable). */
    public void closeAll() {
        for (UUID id : new ArrayList<>(open.keySet())) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) {
                p.closeInventory();
            }
        }
        open.clear();
    }

    /** Açık arayüzleri güncel veriyle yeniden çizer; shop silindiyse kapatır. */
    public void refreshAll() {
        for (UUID id : new ArrayList<>(open.keySet())) {
            ShopGui gui = open.get(id);
            Player p = plugin.getServer().getPlayer(id);
            if (gui == null || p == null) {
                open.remove(id);
                continue;
            }
            if (!gui.render()) {
                p.closeInventory();
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getInventory();
        if (!(top.getHolder() instanceof ShopGui gui)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null || event.getClickedInventory() != top) {
            return;
        }
        gui.handleClick(player, event.getRawSlot(), event.getClick());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof ShopGui) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onMove(InventoryMoveItemEvent event) {
        if (event.getSource().getHolder() instanceof ShopGui || event.getDestination().getHolder() instanceof ShopGui) {
            event.setCancelled(true); // hopper vb. ile eşya çekme/koyma
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof ShopGui gui) {
            UUID id = gui.viewer();
            if (open.get(id) == gui) {
                open.remove(id);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        open.remove(id);
        npcCooldown.remove(id);
        plugin.trade().forget(id);
    }

    public List<UUID> viewers() {
        return new ArrayList<>(open.keySet());
    }
}
