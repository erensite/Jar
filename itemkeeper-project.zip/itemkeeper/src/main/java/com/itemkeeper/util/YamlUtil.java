package com.itemkeeper.util;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.logging.Logger;

/** YAML yükleme/kaydetme yardımcıları: anlaşılır hata mesajları ve atomik kayıt. */
public final class YamlUtil {

    private YamlUtil() {
    }

    /** @return yüklenen yapılandırma; hata varsa konsola açıklama yazar ve null döner. */
    public static YamlConfiguration load(Logger log, File file) {
        YamlConfiguration cfg = new YamlConfiguration();
        try {
            cfg.load(file);
            return cfg;
        } catch (FileNotFoundException e) {
            log.severe("Dosya bulunamadı: " + file.getName());
        } catch (IOException e) {
            log.severe("Dosya okunamadı (" + file.getName() + "): " + e.getMessage());
        } catch (InvalidConfigurationException e) {
            String msg = e.getMessage() == null ? "bilinmeyen hata" : e.getMessage().replace('\n', ' ').replace('\r', ' ');
            log.severe("YAML sözdizimi hatası (" + file.getName() + "): " + msg);
            log.severe("Dosyadaki hatayı düzeltip /ik reload yazın. Eski ayarlar korunuyor.");
        }
        return null;
    }

    /** Geçici dosyaya yazıp taşıyarak kaydeder; yarım yazılmış dosya oluşmaz. */
    public static boolean save(Logger log, File file, YamlConfiguration cfg) {
        try {
            Path target = file.toPath();
            Path tmp = target.resolveSibling(file.getName() + ".tmp");
            Files.writeString(tmp, cfg.saveToString(), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException e) {
            log.severe("Dosya kaydedilemedi (" + file.getName() + "): " + e.getMessage());
            return false;
        }
    }
}
