package com.itemkeeper.util;

import com.itemkeeper.ItemKeeperPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** messages.yml okuyucu. Eksik anahtarlar jar içindeki varsayılandan tamamlanır. */
public final class MessageService {

    private final ItemKeeperPlugin plugin;
    private YamlConfiguration defaults = new YamlConfiguration();
    private YamlConfiguration messages = new YamlConfiguration();

    public MessageService(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    /** @return başarılıysa true; YAML hatasında eski mesajlar korunur ve false döner. */
    public boolean load() {
        YamlConfiguration def = new YamlConfiguration();
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                def.loadFromString(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Varsayılan mesajlar okunamadı: " + e.getMessage());
        }
        defaults = def;
        YamlConfiguration cfg = YamlUtil.load(plugin.getLogger(), new File(plugin.getDataFolder(), "messages.yml"));
        if (cfg == null) {
            return false;
        }
        messages = cfg;
        return true;
    }

    public static String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    private String raw(String key) {
        String v = messages.getString(key);
        if (v == null) {
            v = defaults.getString(key);
        }
        return v == null ? key : v;
    }

    private static String replace(String text, String... kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) {
            text = text.replace("{" + kv[i] + "}", kv[i + 1] == null ? "" : kv[i + 1]);
        }
        return text;
    }

    /** Önek olmadan, renkli ve yer tutucuları doldurulmuş metin. */
    public String format(String key, String... kv) {
        return color(replace(raw(key), kv));
    }

    public List<String> formatList(String key) {
        List<String> src = messages.isList(key) ? messages.getStringList(key) : defaults.getStringList(key);
        List<String> out = new ArrayList<>(src.size());
        for (String s : src) {
            out.add(color(s));
        }
        return out;
    }

    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(color(raw("prefix")) + format(key, kv));
    }
}
