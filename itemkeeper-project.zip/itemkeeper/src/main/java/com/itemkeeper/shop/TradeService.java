package com.itemkeeper.shop;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.hook.MoneyProvider;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Alış/satış mantığı. Tüm çağrılar ana thread'de yapılır. Güvenlik sırası:
 * doğrula -> (alış) parayı çek, eşyayı ver / (satış) eşyayı al, parayı yatır; hata olursa geri al.
 */
public final class TradeService {

    public enum Result {
        SUCCESS, NO_ECONOMY, DISABLED, NOT_ENOUGH_MONEY, INVENTORY_FULL, NOT_ENOUGH_ITEMS, ITEM_MISSING, BUSY, ERROR
    }

    /** İşlem sonucu: money = toplam tutar, items = adet. partial = bir kısım iade edildi. */
    public record Outcome(Result result, double money, int items, boolean partial) {
        static Outcome of(Result r) {
            return new Outcome(r, 0, 0, false);
        }
    }

    private static final int MAX_ITEMS = 64 * 64;

    private final ItemKeeperPlugin plugin;
    private final Map<UUID, Long> last = new HashMap<>();
    private boolean inTrade = false;

    public TradeService(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    public void forget(UUID id) {
        last.remove(id);
    }

    public void clear() {
        last.clear();
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private boolean claim(Player p) {
        if (inTrade) {
            return false; // yeniden giriş (başka plugin olayından tetiklenen çift işlem) engeli
        }
        long now = System.currentTimeMillis();
        long cd = Math.max(0, plugin.getConfig().getLong("trade.click-cooldown-ms", 250));
        Long prev = last.get(p.getUniqueId());
        if (prev != null && now - prev < cd) {
            return false;
        }
        last.put(p.getUniqueId(), now);
        inTrade = true;
        return true;
    }

    private boolean priceOk(double total) {
        double max = plugin.getConfig().getDouble("trade.max-price", 1_000_000_000d);
        return !Double.isNaN(total) && !Double.isInfinite(total) && total > 0 && total <= max * 64;
    }

    public Outcome buy(Player p, Shop shop, ShopItem it, int mult) {
        if (!claim(p)) {
            return Outcome.of(Result.BUSY);
        }
        try {
            MoneyProvider money = plugin.money();
            if (!money.available()) {
                return Outcome.of(Result.NO_ECONOMY);
            }
            if (!it.canBuy()) {
                return Outcome.of(Result.DISABLED);
            }
            int m = Math.max(1, Math.min(64, mult));
            long count = (long) it.amount() * m;
            double total = round2(it.buyPrice() * m);
            if (count < 1 || count > MAX_ITEMS || !priceOk(total)) {
                return Outcome.of(Result.ERROR);
            }
            ItemStack proto = plugin.resolver().create(it.itemId());
            if (proto == null) {
                plugin.resolver().checkAndWarn(shop.id(), it.itemId());
                return Outcome.of(Result.ITEM_MISSING);
            }
            if (!money.has(p, total)) {
                return new Outcome(Result.NOT_ENOUGH_MONEY, total, (int) count, false);
            }
            PlayerInventory inv = p.getInventory();
            if (!canFit(inv, proto, (int) count)) {
                return Outcome.of(Result.INVENTORY_FULL);
            }
            if (!money.withdraw(p, total)) {
                return new Outcome(Result.NOT_ENOUGH_MONEY, total, (int) count, false);
            }
            // Para alındı; şimdi eşyaları ver. Başarısız olursa iade et.
            int leftover;
            try {
                leftover = give(inv, proto, (int) count);
            } catch (RuntimeException e) {
                money.deposit(p, total);
                throw e;
            }
            boolean partial = false;
            double charged = total;
            if (leftover > 0) {
                double refund = round2(total * leftover / count);
                if (refund > 0 && money.deposit(p, refund)) {
                    charged = round2(total - refund);
                }
                partial = true;
            }
            int given = (int) count - leftover;
            log(p, "BUY", shop, it, given, charged);
            return new Outcome(Result.SUCCESS, charged, given, partial);
        } catch (RuntimeException | LinkageError e) {
            plugin.getLogger().severe("Alış işlemi hatası (" + p.getName() + "): " + e);
            return Outcome.of(Result.ERROR);
        } finally {
            inTrade = false;
        }
    }

    public Outcome sell(Player p, Shop shop, ShopItem it, int mult) {
        if (!claim(p)) {
            return Outcome.of(Result.BUSY);
        }
        try {
            MoneyProvider money = plugin.money();
            if (!money.available()) {
                return Outcome.of(Result.NO_ECONOMY);
            }
            if (!it.canSell()) {
                return Outcome.of(Result.DISABLED);
            }
            int m = Math.max(1, Math.min(64, mult));
            long need = (long) it.amount() * m;
            double total = round2(it.sellPrice() * m);
            if (need < 1 || need > MAX_ITEMS || !priceOk(total)) {
                return Outcome.of(Result.ERROR);
            }
            if (!plugin.resolver().exists(it.itemId())) {
                plugin.resolver().checkAndWarn(shop.id(), it.itemId());
                return Outcome.of(Result.ITEM_MISSING);
            }
            PlayerInventory inv = p.getInventory();
            long have = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getItem(i);
                if (plugin.resolver().matches(s, it)) {
                    have += s.getAmount();
                }
            }
            if (have < need) {
                return new Outcome(Result.NOT_ENOUGH_ITEMS, total, (int) need, false);
            }
            // Önce eşyaları al (kaydını tut), sonra parayı yatır; yatırma başarısızsa eşyaları geri ver.
            List<ItemStack> removed = new ArrayList<>();
            long remaining = need;
            for (int i = 0; i < 36 && remaining > 0; i++) {
                ItemStack s = inv.getItem(i);
                if (!plugin.resolver().matches(s, it)) {
                    continue;
                }
                int take = (int) Math.min(remaining, s.getAmount());
                ItemStack taken = s.clone();
                taken.setAmount(take);
                removed.add(taken);
                if (take >= s.getAmount()) {
                    inv.setItem(i, null);
                } else {
                    ItemStack rest = s.clone();
                    rest.setAmount(s.getAmount() - take);
                    inv.setItem(i, rest);
                }
                remaining -= take;
            }
            if (remaining > 0) { // beklenmeyen durum: geri al
                restore(p, removed);
                return Outcome.of(Result.ERROR);
            }
            boolean paid;
            try {
                paid = money.deposit(p, total);
            } catch (RuntimeException e) {
                restore(p, removed);
                throw e;
            }
            if (!paid) {
                restore(p, removed);
                plugin.getLogger().warning("Satış: ekonomi para yatıramadı, eşyalar geri verildi (" + p.getName() + ").");
                return Outcome.of(Result.ERROR);
            }
            log(p, "SELL", shop, it, (int) need, total);
            return new Outcome(Result.SUCCESS, total, (int) need, false);
        } catch (RuntimeException | LinkageError e) {
            plugin.getLogger().severe("Satış işlemi hatası (" + p.getName() + "): " + e);
            return Outcome.of(Result.ERROR);
        } finally {
            inTrade = false;
        }
    }

    /** Envanterde (0-35 depolama slotları) count adet proto için yer var mı? */
    static boolean canFit(PlayerInventory inv, ItemStack proto, int count) {
        int max = Math.max(1, proto.getMaxStackSize());
        long room = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || s.getType().isAir()) {
                room += max;
            } else if (s.isSimilar(proto)) {
                room += Math.max(0, max - s.getAmount());
            }
            if (room >= count) {
                return true;
            }
        }
        return room >= count;
    }

    /** @return verilemeyen adet */
    private static int give(PlayerInventory inv, ItemStack proto, int count) {
        int max = Math.max(1, proto.getMaxStackSize());
        int left = count;
        int notGiven = 0;
        while (left > 0) {
            int n = Math.min(max, left);
            ItemStack st = proto.clone();
            st.setAmount(n);
            Map<Integer, ItemStack> rest = inv.addItem(st);
            for (ItemStack r : rest.values()) {
                notGiven += r.getAmount();
            }
            left -= n;
        }
        return notGiven;
    }

    private void restore(Player p, List<ItemStack> removed) {
        PlayerInventory inv = p.getInventory();
        for (ItemStack st : removed) {
            Map<Integer, ItemStack> rest = inv.addItem(st);
            for (ItemStack r : rest.values()) {
                p.getWorld().dropItem(p.getLocation(), r); // eşya asla kaybolmasın
            }
        }
    }

    private void log(Player p, String type, Shop shop, ShopItem it, int items, double money) {
        if (!plugin.getConfig().getBoolean("logging.transactions", false)) {
            return;
        }
        try {
            Path dir = plugin.getDataFolder().toPath().resolve("logs");
            Files.createDirectories(dir);
            String line = LocalDateTime.now() + " " + type + " " + p.getName() + " (" + p.getUniqueId() + ") shop="
                    + shop.id() + " item=" + it.itemId() + " x" + items + " money=" + money + System.lineSeparator();
            Files.writeString(dir.resolve("transactions.log"), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            plugin.getLogger().warning("İşlem günlüğü yazılamadı: " + e.getMessage());
        }
    }
}
