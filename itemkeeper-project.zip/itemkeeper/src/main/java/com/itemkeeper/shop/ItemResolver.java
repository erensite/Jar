package com.itemkeeper.shop;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.hook.CustomItemProvider;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Eşya kimliği çözümleyici.
 * "minecraft:diamond" veya "DIAMOND" -> vanilla; "namespace:id" (namespace != minecraft) -> ItemsAdder.
 */
public final class ItemResolver {

    private final ItemKeeperPlugin plugin;
    private final Set<String> warned = new HashSet<>();

    public ItemResolver(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
    }

    public static boolean isCustomId(String id) {
        if (id == null) {
            return false;
        }
        int c = id.indexOf(':');
        return c > 0 && !id.substring(0, c).equalsIgnoreCase("minecraft");
    }

    public static String vanillaId(Material m) {
        return "minecraft:" + m.name().toLowerCase(Locale.ROOT);
    }

    public Material vanillaMaterial(String id) {
        if (id == null) {
            return null;
        }
        String n = id.trim();
        if (n.toLowerCase(Locale.ROOT).startsWith("minecraft:")) {
            n = n.substring("minecraft:".length());
        }
        Material m = Material.matchMaterial(n);
        if (m == null || m.isAir() || !m.isItem()) {
            return null;
        }
        return m;
    }

    private CustomItemProvider provider() {
        return plugin.customItems();
    }

    public boolean exists(String id) {
        if (isCustomId(id)) {
            CustomItemProvider p = provider();
            return p != null && p.isLoaded() && p.exists(id);
        }
        return vanillaMaterial(id) != null;
    }

    /** @return yeni eşya kopyası veya null (eşya bulunamadı) */
    public ItemStack create(String id) {
        try {
            if (isCustomId(id)) {
                CustomItemProvider p = provider();
                if (p == null || !p.isLoaded()) {
                    return null;
                }
                ItemStack st = p.create(id);
                return (st == null || st.getType().isAir()) ? null : st;
            }
            Material m = vanillaMaterial(id);
            return m == null ? null : new ItemStack(m);
        } catch (RuntimeException | LinkageError e) {
            plugin.getLogger().warning("Eşya oluşturulamadı '" + id + "': " + e);
            return null;
        }
    }

    /** @return ItemsAdder ID'si veya null (vanilla eşya) */
    public String customIdOf(ItemStack stack) {
        CustomItemProvider p = provider();
        if (p == null || !p.isLoaded() || stack == null) {
            return null;
        }
        try {
            return p.idOf(stack);
        } catch (RuntimeException | LinkageError e) {
            return null;
        }
    }

    /** Shop kaydı için eşyanın kimliği: ItemsAdder ID'si, yoksa minecraft:materyal. */
    public String keyOf(ItemStack stack) {
        String ia = customIdOf(stack);
        return ia != null ? ia : vanillaId(stack.getType());
    }

    public void resetWarnings() {
        warned.clear();
    }

    /** Eşya yoksa konsola (her ID için bir kez) açıklayıcı hata yazar. */
    public void checkAndWarn(String shopId, String id) {
        if (!warned.add(shopId + "|" + id)) {
            return;
        }
        if (isCustomId(id)) {
            CustomItemProvider p = provider();
            if (p == null) {
                plugin.getLogger().severe("Shop '" + shopId + "': '" + id
                        + "' bir ItemsAdder eşyası ama ItemsAdder yüklü değil; bu ürün kullanılamaz.");
            } else if (p.isLoaded() && !p.exists(id)) {
                plugin.getLogger().severe("Shop '" + shopId + "': ItemsAdder eşya ID'si bulunamadı: '" + id
                        + "'. ID'yi (namespace:id) ve ItemsAdder içeriğini kontrol edin.");
            } else if (!p.isLoaded()) {
                warned.remove(shopId + "|" + id); // ItemsAdder yüklenince tekrar kontrol edilecek
            }
        } else if (vanillaMaterial(id) == null) {
            plugin.getLogger().severe("Shop '" + shopId + "': geçersiz Minecraft eşyası: '" + id + "'.");
        }
    }

    /** Oyuncu envanterindeki bir yığın bu shop ürününe karşılık geliyor mu? (satış için) */
    public boolean matches(ItemStack stack, ShopItem item) {
        if (stack == null || stack.getType().isAir()) {
            return false;
        }
        String id = item.itemId();
        if (isCustomId(id)) {
            String ia = customIdOf(stack);
            return ia != null && ia.equalsIgnoreCase(id);
        }
        Material m = vanillaMaterial(id);
        if (m == null || stack.getType() != m) {
            return false;
        }
        if (customIdOf(stack) != null) {
            return false; // ItemsAdder eşyası vanilla ürün olarak satılamaz
        }
        return !plugin.getConfig().getBoolean("trade.strict-vanilla-sell", true) || isPlain(stack);
    }

    @SuppressWarnings("deprecation")
    private boolean isPlain(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return true;
        }
        if (meta instanceof BlockStateMeta) {
            return false; // kutu/sandık içeriği kaybolmasın
        }
        if (meta instanceof Damageable d && d.hasDamage()) {
            return false; // hasarlı eşya tam fiyatla satılamaz
        }
        return !meta.hasDisplayName() && !meta.hasLore() && !meta.hasEnchants()
                && !meta.hasCustomModelData() && !meta.hasAttributeModifiers();
    }
}
