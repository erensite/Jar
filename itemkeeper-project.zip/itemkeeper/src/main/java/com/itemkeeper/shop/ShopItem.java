package com.itemkeeper.shop;

import java.util.ArrayList;
import java.util.List;

/**
 * Bir shop ürünü. Fiyat 0 (veya altı) = o işlem kapalı. NaN/sonsuz/negatif değerler
 * yükleme ve komut aşamasında reddedilir; setter'lar ek olarak güvenli değere çeker.
 */
public final class ShopItem {
    private final String itemId;
    private int amount;
    private double buyPrice;
    private double sellPrice;
    private String category;
    private String name;
    private String icon;
    private List<String> lore = new ArrayList<>();

    public ShopItem(String itemId, int amount, double buyPrice, double sellPrice) {
        this.itemId = itemId;
        this.amount = Math.max(1, Math.min(64, amount));
        this.buyPrice = sanitize(buyPrice);
        this.sellPrice = sanitize(sellPrice);
    }

    public static double sanitize(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v) || v < 0) {
            return 0;
        }
        return Math.round(v * 100.0) / 100.0;
    }

    public String itemId() {
        return itemId;
    }

    public int amount() {
        return amount;
    }

    public double buyPrice() {
        return buyPrice;
    }

    public double sellPrice() {
        return sellPrice;
    }

    public boolean canBuy() {
        return buyPrice > 0;
    }

    public boolean canSell() {
        return sellPrice > 0;
    }

    public void setBuyPrice(double v) {
        this.buyPrice = sanitize(v);
    }

    public void setSellPrice(double v) {
        this.sellPrice = sanitize(v);
    }

    public String category() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String name() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String icon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<String> lore() {
        return lore;
    }

    public void setLore(List<String> lore) {
        this.lore = lore == null ? new ArrayList<>() : new ArrayList<>(lore);
    }
}
