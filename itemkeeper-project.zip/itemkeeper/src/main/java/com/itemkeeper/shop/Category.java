package com.itemkeeper.shop;

/** Shop kategorisi. */
public final class Category {
    private final String id;
    private final String name;
    private final String icon;

    public Category(String id, String name, String icon) {
        this.id = id;
        this.name = name;
        this.icon = icon;
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public String icon() {
        return icon;
    }
}
