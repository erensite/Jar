package com.itemkeeper.shop;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.util.YamlUtil;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** shops.yml okuma/yazma ve shop kayıt defteri. */
public final class ShopManager {

    public static final Pattern ID_PATTERN = Pattern.compile("[a-z0-9_-]{1,32}");

    private final ItemKeeperPlugin plugin;
    private final File file;
    private Map<String, Shop> shops = new LinkedHashMap<>();

    public ShopManager(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shops.yml");
    }

    public static boolean validId(String id) {
        return id != null && ID_PATTERN.matcher(id).matches();
    }

    public Shop get(String id) {
        return id == null ? null : shops.get(id.toLowerCase(Locale.ROOT));
    }

    public List<Shop> all() {
        return new ArrayList<>(shops.values());
    }

    public int count() {
        return shops.size();
    }

    /** @return false ise YAML hatası vardı ve mevcut shop'lar korundu. */
    public boolean load() {
        YamlConfiguration cfg = YamlUtil.load(plugin.getLogger(), file);
        if (cfg == null) {
            return false;
        }
        Map<String, Shop> loaded = new LinkedHashMap<>();
        ConfigurationSection root = cfg.getConfigurationSection("shops");
        if (root != null) {
            for (String key : root.getKeys(false)) {
                ConfigurationSection sec = root.getConfigurationSection(key);
                if (sec == null) {
                    plugin.getLogger().warning("shops.yml: '" + key + "' bir shop bölümü değil, atlandı.");
                    continue;
                }
                String id = key.toLowerCase(Locale.ROOT);
                if (!validId(id)) {
                    plugin.getLogger().warning("shops.yml: geçersiz shop id '" + key + "' atlandı (a-z, 0-9, -, _).");
                    continue;
                }
                if (loaded.containsKey(id)) {
                    plugin.getLogger().warning("shops.yml: '" + key + "' tekrar tanımlanmış, atlandı.");
                    continue;
                }
                loaded.put(id, parseShop(id, sec));
            }
        }
        this.shops = loaded;
        plugin.resolver().resetWarnings();
        validateAll();
        return true;
    }

    private Shop parseShop(String id, ConfigurationSection sec) {
        Shop shop = new Shop(id, sec.getString("title", "&6" + id));
        shop.setPermission(sec.getString("permission"));
        ConfigurationSection cats = sec.getConfigurationSection("categories");
        if (cats != null) {
            for (String ck : cats.getKeys(false)) {
                ConfigurationSection cs = cats.getConfigurationSection(ck);
                if (cs == null) {
                    continue;
                }
                shop.categories().put(ck, new Category(ck, cs.getString("name", ck), cs.getString("icon")));
            }
        }
        List<Map<?, ?>> list = sec.getMapList("items");
        int index = 0;
        for (Map<?, ?> m : list) {
            index++;
            ShopItem item = parseItem(id, index, m, shop);
            if (item != null) {
                shop.items().add(item);
            }
        }
        return shop;
    }

    private ShopItem parseItem(String shopId, int index, Map<?, ?> m, Shop shop) {
        String where = "shops.yml [" + shopId + " #" + index + "]: ";
        Object rawItem = m.get("item");
        if (rawItem == null || String.valueOf(rawItem).isBlank()) {
            plugin.getLogger().warning(where + "'item' alanı yok, ürün atlandı.");
            return null;
        }
        String itemId = String.valueOf(rawItem).trim();
        Double buy = readPrice(m.get("buy-price"), where + "buy-price");
        Double sell = readPrice(m.get("sell-price"), where + "sell-price");
        if (buy == null || sell == null) {
            return null;
        }
        int amount = 1;
        Object a = m.get("amount");
        if (a instanceof Number n) {
            amount = n.intValue();
        } else if (a != null) {
            plugin.getLogger().warning(where + "'amount' sayı olmalı, ürün atlandı.");
            return null;
        }
        if (amount < 1 || amount > 64) {
            plugin.getLogger().warning(where + "'amount' 1-64 arasında olmalı (" + amount + "), ürün atlandı.");
            return null;
        }
        double max = plugin.getConfig().getDouble("trade.max-price", 1_000_000_000d);
        if (buy > max || sell > max) {
            plugin.getLogger().warning(where + "fiyat izin verilen en yüksek değeri aşıyor (" + max + "), ürün atlandı.");
            return null;
        }
        ShopItem item = new ShopItem(itemId, amount, buy, sell);
        Object cat = m.get("category");
        if (cat != null) {
            String c = String.valueOf(cat);
            if (!shop.categories().containsKey(c)) {
                plugin.getLogger().warning(where + "kategori '" + c + "' tanımlı değil; ürün kategorisiz sayılacak.");
            } else {
                item.setCategory(c);
            }
        }
        if (m.get("name") != null) {
            item.setName(String.valueOf(m.get("name")));
        }
        if (m.get("icon") != null) {
            item.setIcon(String.valueOf(m.get("icon")));
        }
        Object lore = m.get("lore");
        if (lore instanceof List<?> l) {
            List<String> out = new ArrayList<>();
            for (Object o : l) {
                out.add(String.valueOf(o));
            }
            item.setLore(out);
        }
        if (!item.canBuy() && !item.canSell()) {
            plugin.getLogger().warning(where + "alış ve satış fiyatı ikisi de kapalı (0); ürün yine de listelenecek ama işlem yapılamaz.");
        }
        return item;
    }

    /** @return null: hata (log yazıldı); aksi halde 0 veya pozitif fiyat. */
    private Double readPrice(Object o, String field) {
        if (o == null) {
            return 0d;
        }
        double v;
        if (o instanceof Number n) {
            v = n.doubleValue();
        } else {
            try {
                v = Double.parseDouble(String.valueOf(o).trim().replace(',', '.'));
            } catch (NumberFormatException e) {
                plugin.getLogger().warning(field + " sayı değil ('" + o + "'), ürün atlandı.");
                return null;
            }
        }
        if (Double.isNaN(v) || Double.isInfinite(v) || v < 0) {
            plugin.getLogger().warning(field + " geçersiz (" + o + "): negatif/NaN/sonsuz fiyat kabul edilmez, ürün atlandı.");
            return null;
        }
        return v;
    }

    /** ItemsAdder yüklendiyse eşya ID'lerini doğrular ve eksikleri konsola yazar. */
    public void validateAll() {
        for (Shop shop : shops.values()) {
            for (ShopItem item : shop.items()) {
                plugin.resolver().checkAndWarn(shop.id(), item.itemId());
                if (item.icon() != null) {
                    plugin.resolver().checkAndWarn(shop.id(), item.icon());
                }
            }
        }
    }

    public boolean save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Shop shop : shops.values()) {
            String base = "shops." + shop.id();
            cfg.set(base + ".title", shop.title());
            if (shop.permission() != null) {
                cfg.set(base + ".permission", shop.permission());
            }
            for (Category c : shop.categories().values()) {
                cfg.set(base + ".categories." + c.id() + ".name", c.name());
                if (c.icon() != null) {
                    cfg.set(base + ".categories." + c.id() + ".icon", c.icon());
                }
            }
            List<Map<String, Object>> items = new ArrayList<>();
            for (ShopItem it : shop.items()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("item", it.itemId());
                m.put("amount", it.amount());
                if (it.canBuy()) {
                    m.put("buy-price", it.buyPrice());
                }
                if (it.canSell()) {
                    m.put("sell-price", it.sellPrice());
                }
                if (it.category() != null) {
                    m.put("category", it.category());
                }
                if (it.name() != null) {
                    m.put("name", it.name());
                }
                if (it.icon() != null) {
                    m.put("icon", it.icon());
                }
                if (!it.lore().isEmpty()) {
                    m.put("lore", new ArrayList<>(it.lore()));
                }
                items.add(m);
            }
            cfg.set(base + ".items", items);
        }
        if (shops.isEmpty()) {
            cfg.createSection("shops");
        }
        return YamlUtil.save(plugin.getLogger(), file, cfg);
    }

    public Shop create(String id) {
        Shop s = new Shop(id, "&6" + id);
        shops.put(id, s);
        return s;
    }

    public boolean delete(String id) {
        return shops.remove(id.toLowerCase(Locale.ROOT)) != null;
    }
}
