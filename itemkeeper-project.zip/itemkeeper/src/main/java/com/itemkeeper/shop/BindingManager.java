package com.itemkeeper.shop;

import com.itemkeeper.ItemKeeperPlugin;
import com.itemkeeper.util.YamlUtil;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** NPC id -> shop id bağlantıları (npc-bindings.yml). */
public final class BindingManager {

    private final ItemKeeperPlugin plugin;
    private final File file;
    private Map<Integer, String> bindings = new TreeMap<>();

    public BindingManager(ItemKeeperPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "npc-bindings.yml");
    }

    public boolean load() {
        YamlConfiguration cfg = YamlUtil.load(plugin.getLogger(), file);
        if (cfg == null) {
            return false;
        }
        Map<Integer, String> loaded = new TreeMap<>();
        ConfigurationSection sec = cfg.getConfigurationSection("bindings");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                String shopId = sec.getString(key);
                int npcId;
                try {
                    npcId = Integer.parseInt(key.trim());
                } catch (NumberFormatException e) {
                    plugin.getLogger().warning("npc-bindings.yml: NPC id sayı olmalı ('" + key + "'), atlandı.");
                    continue;
                }
                if (shopId == null || shopId.isBlank()) {
                    plugin.getLogger().warning("npc-bindings.yml: NPC #" + npcId + " için shop id boş, atlandı.");
                    continue;
                }
                loaded.put(npcId, shopId.toLowerCase(Locale.ROOT));
            }
        }
        this.bindings = loaded;
        return true;
    }

    public boolean save() {
        YamlConfiguration cfg = new YamlConfiguration();
        ConfigurationSection sec = cfg.createSection("bindings");
        for (Map.Entry<Integer, String> e : bindings.entrySet()) {
            sec.set(String.valueOf(e.getKey()), e.getValue());
        }
        return YamlUtil.save(plugin.getLogger(), file, cfg);
    }

    public String get(int npcId) {
        return bindings.get(npcId);
    }

    /** @return önceki shop id veya null */
    public String bind(int npcId, String shopId) {
        return bindings.put(npcId, shopId.toLowerCase(Locale.ROOT));
    }

    public boolean unbind(int npcId) {
        return bindings.remove(npcId) != null;
    }

    /** Bir shop silindiğinde ona bağlı tüm NPC'leri çözer. @return çözülen sayısı */
    public int unbindShop(String shopId) {
        List<Integer> toRemove = new ArrayList<>();
        for (Map.Entry<Integer, String> e : bindings.entrySet()) {
            if (e.getValue().equalsIgnoreCase(shopId)) {
                toRemove.add(e.getKey());
            }
        }
        for (Integer id : toRemove) {
            bindings.remove(id);
        }
        return toRemove.size();
    }

    public Map<Integer, String> all() {
        return new TreeMap<>(bindings);
    }

    public int count() {
        return bindings.size();
    }
}
