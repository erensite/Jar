package com.itemkeeper.shop;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Bir shop: başlık, kategoriler ve ürünler. Yalnızca ana thread'de değiştirilir. */
public final class Shop {
    private final String id;
    private String title;
    private String permission;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final List<ShopItem> items = new ArrayList<>();

    public Shop(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public String id() {
        return id;
    }

    public String title() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /** @return gerekli yetki veya null */
    public String permission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = (permission == null || permission.isBlank()) ? null : permission;
    }

    public Map<String, Category> categories() {
        return categories;
    }

    public List<ShopItem> items() {
        return items;
    }

    /** Listede referans eşitliğiyle arar (ürünler equals tanımlamaz). */
    public boolean containsItem(ShopItem item) {
        for (ShopItem s : items) {
            if (s == item) {
                return true;
            }
        }
        return false;
    }
}
