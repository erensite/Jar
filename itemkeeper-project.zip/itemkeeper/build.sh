#!/bin/sh
# ItemKeeper derleme betiği. Gereken: JDK 17+ ve Maven 3.8+, internet (Paper/Vault bağımlılıkları için).
set -e
cd "$(dirname "$0")"
for f in libs/ItemsAdder_4_0_15.jar libs/znpcs-5_3.jar; do
  if [ ! -f "$f" ]; then
    echo "HATA: $f bulunamadı. Kendi ItemsAdder ve ZNPCs JAR'larınızı libs/ klasörüne bu isimlerle kopyalayın." >&2
    exit 1
  fi
done
mvn -B clean package
echo "Hazır: target/itemkeeper.jar"
