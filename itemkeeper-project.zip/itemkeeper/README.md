# ItemKeeper

ItemsAdder eşyalarıyla çalışan, ZNPCs NPC'lerine bağlanabilen, Vault ekonomisini kullanan bağımsız shop plugin'i.

## Durum (dürüst özet)

- **Kaynak kod eksiksiz**: 22 Java dosyası, `pom.xml`, `plugin.yml`, varsayılan YAML'lar.
- **Maven ile derlenip JAR üretilmedi.** Geliştirme ortamında Maven, `javac` binary'si, Paper API ve internet yoktu.
  Yapılan tek doğrulama: `jdk.compiler` ile **stub'lara karşı tip kontrolü** (Bukkit/Vault için elle yazılmış
  minimal stub'lar + gerçek ZNPCs 5.3 ve ItemsAdder 4.0.15 jar'ları). Bu, gerçek Paper API ile derlemenin yerine geçmez.
- **Sunucuda çalıştırılıp test edilmedi.** Otomatik test yok.

## Derleme

1. JDK 17+ ve Maven kurun.
2. `libs/` klasörüne `ItemsAdder_4_0_15.jar` ve `znpcs-5_3.jar` dosyalarını kopyalayın (bkz. `libs/README.txt`).
3. `./build.sh` (veya `mvn clean package`) -> `target/itemkeeper.jar`

Derleme hatası çıkarsa (özellikle Paper/Vault API farkları) çıktıyı paylaşın, düzeltilir.

## Kurulum

`itemkeeper.jar` dosyasını `plugins/` içine atın. Gerekli: Paper tabanlı sunucu. Opsiyonel: Vault + bir ekonomi plugin'i
(olmadan alış/satış çalışmaz), ItemsAdder, ZNPCs (yoksa ilgili özellik kapanır, plugin çökmez).
İlk açılışta `plugins/ItemKeeper/` altına `config.yml`, `shops.yml`, `npc-bindings.yml`, `messages.yml` oluşur
(örnek shop: `ornek`). `logs/` yalnızca `logging.transactions: true` ise oluşur.

## Komutlar ve yetkiler

| Komut | Yetki |
|---|---|
| `/ik help` | - |
| `/ik reload` | `itemkeeper.reload` |
| `/ik shop list`, `/ik shop open <id>` | `itemkeeper.shop.open` |
| `/ik shop create <id>` | `itemkeeper.shop.create` |
| `/ik shop delete <id>` | `itemkeeper.shop.delete` |
| `/ik shop edit <id>` | `itemkeeper.shop.edit` |
| `/ik npc bind <npc-id> <shop-id>`, `unbind`, `info`, `list` | `itemkeeper.npc.bind` |
| `/ik item info`, `/ik item add <shop> <alış> <satış> [adet]`, `/ik item remove <shop> <sıra>` | `itemkeeper.item.manage` |

`itemkeeper.admin` hepsini kapsar. Hepsinin varsayılanı `op`. Fiyat yerine `-` yazmak o işlemi kapatır.
NPC ile shop açmak için ayrıca yetki gerekmez (shop'a `permission:` eklenirse gerekir).

## Kullanım

- GUI: sol tık = satın al, sağ tık = sat, alttaki butonlarla sayfa/kategori/miktar çarpanı.
- Düzenleme GUI'si: sol/sağ tık alış fiyatı +/-, Shift+sol/sağ satış fiyatı +/-, Q = ürünü kaldır.
- `item remove` için `<sıra>`, `item add` çıktısındaki 1 tabanlı sıradır.
- ItemsAdder eşyası: `item: "namespace:id"`; vanilla: `minecraft:diamond` veya `DIAMOND`.

## Doğrulanan API'ler (jar'lardan okundu)

- ZNPCs 5.3 (plugin adı `ServersNPC`): `NPCInteractEvent#getPlayer/getNpc/isRightClick/isLeftClick`,
  `NPC.find(int)`, `NPC.all()`, `NPC#getNpcPojo().getId()` (NPC kimliği `int`).
- ItemsAdder 4.0.15: `CustomStack.getInstance/byItemStack/isInRegistry`, `CustomStack#getItemStack/getNamespacedID`,
  `ItemsAdder.areItemsLoaded()` (bu sürümde `@Deprecated` işaretli), `ItemsAdderLoadDataEvent`.
- Vault: `Economy` servisi (VaultAPI 1.7).

## Uyumluluk ve sınırlamalar

- Derleme hedefi: Paper API 1.20.1, Java 17 bytecode. API'de değişen `InventoryView` metotları kullanılmadı.
- **1.20.1 - 1.21.x**: bu API yüzeyiyle çalışması beklenir, **test edilmedi**.
- **26.x**: Paper API'si ve ZNPCs 5.3'ün bu sürümleri destekleyip desteklemediği **doğrulanamadı**; desteklendiği iddia edilmiyor.
  ZNPCs sürüme özel NMS/paket kodu kullanır; NPC tıklaması ZNPCs yeni sürümde çalışmıyorsa ItemKeeper'a bağlı değildir.
- Shopkeepers: yüklenen `ShopkeepersAddon` Shopkeepers plugin'ine bağımlı bir eklenti; ItemKeeper ona veya Shopkeepers'a
  bağlanmaz, kendi shop sistemini kullanır.
- `/ik` komutlarıyla kaydedilince `shops.yml` içindeki yorum satırları silinir.
- Düzenleme GUI'sinde ürün ekleme yok (`/ik item add` kullanın).
