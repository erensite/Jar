Bu klasöre KENDİ kopyalarınızı koyun (derleme için gerekli, çıktıya gömülmez):
  ItemsAdder_4_0_15.jar   (ItemsAdder 4.0.15)
  znpcs-5_3.jar           (ZNPCs 5.3)
Bu JAR'lar üçüncü taraf yazılımdır; bu projeyle birlikte dağıtılmaz.
